return {
	mod_name = {
		en = "MasterItem Community Patch",
	},
	mod_description = {
		en = "Patches MasterItems for easier modding.",
	},
}
