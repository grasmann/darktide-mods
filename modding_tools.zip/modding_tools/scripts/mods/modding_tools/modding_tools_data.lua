local mod = get_mod("modding_tools")

return {
	name = "modding_tools",
	description = mod:localize("mod_description"),
	is_togglable = true,
}
