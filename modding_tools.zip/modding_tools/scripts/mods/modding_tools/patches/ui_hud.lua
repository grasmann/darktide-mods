local mod = get_mod("modding_tools")

-- ##### ┌─┐┌─┐┬─┐┌─┐┌─┐┬─┐┌┬┐┌─┐┌┐┌┌─┐┌─┐ ############################################################################
-- ##### ├─┘├┤ ├┬┘├┤ │ │├┬┘│││├─┤││││  ├┤  ############################################################################
-- ##### ┴  └─┘┴└─└  └─┘┴└─┴ ┴┴ ┴┘└┘└─┘└─┘ ############################################################################

--#region Performance
    local CLASS = CLASS
--#endregion

-- ##### ┌─┐┬  ┌─┐┌─┐┌─┐  ┬ ┬┌─┐┌─┐┬┌─┌─┐ #############################################################################
-- ##### │  │  ├─┤└─┐└─┐  ├─┤│ ││ │├┴┐└─┐ #############################################################################
-- ##### └─┘┴─┘┴ ┴└─┘└─┘  ┴ ┴└─┘└─┘┴ ┴└─┘ #############################################################################

mod:hook(CLASS.UIHud, "init", function(func, self, elements, visibility_groups, params, ...)
    -- Original function
    local result = func(self, elements, visibility_groups, params, ...)
    -- Setup forward gui
    mod:inject_forward_gui_into_class(self)
    -- return result
    return result
end)

mod:hook(CLASS.UIHud, "destroy", function(func, self, disable_world_bloom, ...)
    -- Destroy forward gui
    mod:destroy_forward_gui_in_class(self)
    -- Original function
    return func(self, disable_world_bloom, ...)
end)