return {
	mod_description = {
		en = "modding_tools description",
	},
	show_console = {
		en = "Toggle Console",
	},
	redirect_inspect = {
		en = "Redirect to inspector",
	},
	hook_dtf = {
		en = "Redirect mod:dtf to inspector",
	},
	redirect_console = {
		en = "Redirect to console",
	},
	hook_echo = {
		en = "Redirect mod:echo to console",
	},
	hook_error = {
		en = "Redirect mod:error to console",
	},
	hook_warning = {
		en = "Redirect mod:warning to console",
	},
	hook_info = {
		en = "Redirect mod:info to console",
	},
	hook_notify = {
		en = "Redirect mod:notify to console",
	},
}
