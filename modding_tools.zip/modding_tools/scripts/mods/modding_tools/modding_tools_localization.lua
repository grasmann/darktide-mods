return {
	mod_description = {
		en = "modding_tools description",
	},
}
