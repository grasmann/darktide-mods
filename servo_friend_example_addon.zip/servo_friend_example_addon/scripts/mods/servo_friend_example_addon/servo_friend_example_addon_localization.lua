return {
	mod_title = {
		en = "Funny Servo Friend Hat",
	},
	mod_description = {
		en = "Funny Servo Friend Hat",
	},
	mod_option_show_hat = {
		en = "Show Hat",
	},
	mod_option_show_hat_tooltip = {
		en = "Show Hat",
	},
}
