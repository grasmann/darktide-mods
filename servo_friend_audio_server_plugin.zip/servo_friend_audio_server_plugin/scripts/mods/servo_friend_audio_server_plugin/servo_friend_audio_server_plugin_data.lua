local mod = get_mod("servo_friend_audio_server_plugin")

return {
	name = "servo_friend_audio_server_plugin",
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
		},
	}
}
