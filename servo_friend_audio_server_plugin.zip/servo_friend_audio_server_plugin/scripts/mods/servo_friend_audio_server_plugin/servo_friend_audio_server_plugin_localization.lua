return {
	mod_description = {
		en = "servo_friend_audio_server_plugin description",
	},
}
