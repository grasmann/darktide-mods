local mod = get_mod("extended_weapon_customization_base_additions")

return {
	name = mod:localize("mod_title"),
	description = mod:localize("mod_description"),
	is_togglable = true,
}
