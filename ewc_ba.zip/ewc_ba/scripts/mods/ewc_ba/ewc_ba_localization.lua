return {
	mod_title = {
		en = "Extended Weapon Customization Base Additions",
	},
	mod_description = {
		en = "Basic custom additions for extended weapon customization.",
	},
}
