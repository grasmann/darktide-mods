local mod = get_mod("cancel_loading")

return {
	name = mod:localize("mod_title"),
	description = mod:localize("mod_description"),
}
