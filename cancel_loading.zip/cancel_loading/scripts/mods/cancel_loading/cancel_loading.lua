local mod = get_mod("cancel_loading")

-- ##### ┬─┐┌─┐┌─┐ ┬ ┬┬┬─┐┌─┐ #########################################################################################
-- ##### ├┬┘├┤ │─┼┐│ ││├┬┘├┤  #########################################################################################
-- ##### ┴└─└─┘└─┘└└─┘┴┴└─└─┘ #########################################################################################
--#region Require
    local UIWidget = mod:original_require("scripts/managers/ui/ui_widget")
    local UISoundEvents = mod:original_require("scripts/settings/ui/ui_sound_events")
    local ButtonPassTemplates = mod:original_require("scripts/ui/pass_templates/button_pass_templates")
    local Definitions = mod:original_require("scripts/ui/views/mission_intro_view/mission_intro_view_definitions")
--#endregion

-- ##### ┌─┐┌─┐┬─┐┌─┐┌─┐┬─┐┌┬┐┌─┐┌┐┌┌─┐┌─┐ ############################################################################
-- ##### ├─┘├┤ ├┬┘├┤ │ │├┬┘│││├─┤││││  ├┤  ############################################################################
-- ##### ┴  └─┘┴└─└  └─┘┴└─┴ ┴┴ ┴┘└┘└─┘└─┘ ############################################################################
--#region local functions
    local CLASS = CLASS
    local managers = Managers
    local callback = callback
    local utf8_upper = Utf8.upper
    local table_clone = table.clone
--#endregion

-- ##### ┌┬┐┌─┐┌┬┐┌─┐ #################################################################################################
-- #####  ││├─┤ │ ├─┤ #################################################################################################
-- ##### ─┴┘┴ ┴ ┴ ┴ ┴ #################################################################################################
mod.abort_mission = false

mod:hook_require("scripts/ui/views/mission_intro_view/mission_intro_view_definitions", function(instance)

    local equip_button_size = {374, 76}

    -- Create cancel button scenegraph
	instance.scenegraph_definition.cancel_button = {
		vertical_alignment = "bottom",
		parent = "canvas",
		horizontal_alignment = "center",
		size = equip_button_size,
		position = {0, -20, 1}
	}
	-- Create cancel button widget
	instance.widget_definitions.cancel_button = UIWidget.create_definition(table_clone(ButtonPassTemplates.default_button), "cancel_button", {
		gamepad_action = "confirm_pressed",
		text = utf8_upper(mod:localize("loc_cancel_button")),
		hotspot = {
			on_pressed_sound = UISoundEvents.weapons_skin_confirm
		}
	})
	instance.widget_definitions.cancel_button.content.original_text = utf8_upper(mod:localize("loc_cancel_button"))

end)

mod:hook_require("scripts/ui/views/mission_intro_view/mission_intro_view", function(instance)

    instance.init_custom = function(self)
        self._widgets = {}
        self._widgets_by_name = {}
    end

    instance.cb_on_cancel_pressed = function(self)
        managers.party_immaterium:leave_party()
    end

    instance.custom_enter = function(self)
        local widget = self:_create_widget("cancel_button", Definitions.widget_definitions.cancel_button)
        self._widgets_by_name.cancel_button = widget
        self._widgets[#self._widgets + 1] = widget
        widget.content.hotspot.pressed_callback = callback(self, "cb_on_cancel_pressed")
    end

end)

mod:hook(CLASS.MissionIntroView, "init", function(func, self, settings, context, ...)
    -- Original function
    func(self, settings, context, ...)
    -- Custom
    self:init_custom()
end)

mod:hook(CLASS.MissionIntroView, "on_enter", function(func, self, ...)
    -- Original function
    func(self, ...)
    -- Custom
    self:custom_enter()
end)