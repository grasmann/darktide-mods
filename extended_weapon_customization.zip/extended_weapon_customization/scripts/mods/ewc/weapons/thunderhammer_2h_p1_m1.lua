local mod = get_mod("extended_weapon_customization")

-- ##### ┬─┐┌─┐┌─┐ ┬ ┬┬┬─┐┌─┐ #########################################################################################
-- ##### ├┬┘├┤ │─┼┐│ ││├┬┘├┤  #########################################################################################
-- ##### ┴└─└─┘└─┘└└─┘┴┴└─└─┘ #########################################################################################

local trinket_hooks = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/trinket_hook")
local emblem_left = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/emblem_left")
local emblem_right = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/emblem_right")

-- ##### ┌─┐┌─┐┬─┐┌─┐┌─┐┬─┐┌┬┐┌─┐┌┐┌┌─┐┌─┐ ############################################################################
-- ##### ├─┘├┤ ├┬┘├┤ │ │├┬┘│││├─┤││││  ├┤  ############################################################################
-- ##### ┴  └─┘┴└─└  └─┘┴└─┴ ┴┴ ┴┘└┘└─┘└─┘ ############################################################################
-- #region Performance
    local table = table
    local vector3 = Vector3
    local vector3_box = Vector3Box
    local vector3_zero = vector3.zero
    local table_merge_recursive = table.merge_recursive
--#endregion

-- ##### ┌┬┐┌─┐┌┬┐┌─┐ #################################################################################################
-- #####  ││├─┤ │ ├─┤ #################################################################################################
-- ##### ─┴┘┴ ┴ ┴ ┴ ┴ #################################################################################################

local _item = "content/items/weapons/player"
local _item_melee = _item.."/melee"
local _item_ranged = _item.."/ranged"

return {
    attachments = {
        emblem_left = emblem_left,
        emblem_right = emblem_right,
        trinket_hook = trinket_hooks,
        shaft = {
            thunder_hammer_shaft_01 = {
                replacement_path = _item_ranged.."/shafts/thunder_hammer_shaft_01",
                icon_render_unit_rotation_offset = {90, -30, 0},
                icon_render_camera_position_offset = {.025, -3, .65},
            },
            thunder_hammer_shaft_02 = {
                replacement_path = _item_ranged.."/shafts/thunder_hammer_shaft_02",
                icon_render_unit_rotation_offset = {90, -30, 0},
                icon_render_camera_position_offset = {.025, -3, .65},
            },
            thunder_hammer_shaft_03 = {
                replacement_path = _item_ranged.."/shafts/thunder_hammer_shaft_03",
                icon_render_unit_rotation_offset = {90, -30, 0},
                icon_render_camera_position_offset = {.025, -3, .65},
            },
            thunder_hammer_shaft_04 = {
                replacement_path = _item_ranged.."/shafts/thunder_hammer_shaft_04",
                icon_render_unit_rotation_offset = {90, -30, 0},
                icon_render_camera_position_offset = {.025, -3, .65},
            },
            thunder_hammer_shaft_05 = {
                replacement_path = _item_ranged.."/shafts/thunder_hammer_shaft_05",
                icon_render_unit_rotation_offset = {90, -30, 0},
                icon_render_camera_position_offset = {.025, -3, .65},
            },
            thunder_hammer_shaft_ml01 = {
                replacement_path = _item_ranged.."/shafts/thunder_hammer_shaft_ml01",
                icon_render_unit_rotation_offset = {90, -30, 0},
                icon_render_camera_position_offset = {.025, -3, .65},
            },
        },
        head = {
            thunder_hammer_head_01 = {
                replacement_path = _item_melee.."/heads/thunder_hammer_head_01",
                icon_render_unit_rotation_offset = {90, 30, 0},
                icon_render_camera_position_offset = {-.025, -2.75, .3},
            },
            thunder_hammer_head_02 = {
                replacement_path = _item_melee.."/heads/thunder_hammer_head_02",
                icon_render_unit_rotation_offset = {90, 30, 0},
                icon_render_camera_position_offset = {-.025, -2.75, .3},
            },
            thunder_hammer_head_03 = {
                replacement_path = _item_melee.."/heads/thunder_hammer_head_03",
                icon_render_unit_rotation_offset = {90, 30, 0},
                icon_render_camera_position_offset = {-.025, -2.75, .3},
            },
            thunder_hammer_head_04 = {
                replacement_path = _item_melee.."/heads/thunder_hammer_head_04",
                icon_render_unit_rotation_offset = {90, 30, 0},
                icon_render_camera_position_offset = {-.025, -2.75, .3},
            },
            thunder_hammer_head_05 = {
                replacement_path = _item_melee.."/heads/thunder_hammer_head_05",
                icon_render_unit_rotation_offset = {90, 30, 0},
                icon_render_camera_position_offset = {-.025, -2.75, .3},
            },
            thunder_hammer_head_06 = {
                replacement_path = _item_melee.."/heads/thunder_hammer_head_06",
                icon_render_unit_rotation_offset = {90, 30, 0},
                icon_render_camera_position_offset = {-.025, -2.75, .3},
            },
            thunder_hammer_head_ml01 = {
                replacement_path = _item_melee.."/heads/thunder_hammer_head_ml01",
                icon_render_unit_rotation_offset = {90, 30, 0},
                icon_render_camera_position_offset = {-.025, -2.75, .3},
            },
        },
        connector = {
            thunder_hammer_connector_01 = {
                replacement_path = _item_melee.."/connectors/thunder_hammer_connector_01",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {-.025, -1.25, .275},
            },
            thunder_hammer_connector_02 = {
                replacement_path = _item_melee.."/connectors/thunder_hammer_connector_02",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {-.025, -1.25, .275},
            },
            thunder_hammer_connector_03 = {
                replacement_path = _item_melee.."/connectors/thunder_hammer_connector_03",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {-.05, -1.25, .275},
            },
            thunder_hammer_connector_04 = {
                replacement_path = _item_melee.."/connectors/thunder_hammer_connector_04",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {-.025, -1.25, .275},
            },
            thunder_hammer_connector_05 = {
                replacement_path = _item_melee.."/connectors/thunder_hammer_connector_05",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {-.025, -1.25, .275},
            },
            thunder_hammer_connector_06 = {
                replacement_path = _item_melee.."/connectors/thunder_hammer_connector_06",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {-.025, -1.25, .275},
            },
            thunder_hammer_connector_ml01 = {
                replacement_path = _item_melee.."/connectors/thunder_hammer_connector_ml01",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {-.025, -1.25, .275},
            },
        },
        pommel = {
            thunder_hammer_pommel_01 = {
                replacement_path = _item_melee.."/pommels/thunder_hammer_pommel_01",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {0, -.5, .1},
            },
            thunder_hammer_pommel_02 = {
                replacement_path = _item_melee.."/pommels/thunder_hammer_pommel_02",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {0, -.5, .1},
            },
            thunder_hammer_pommel_03 = {
                replacement_path = _item_melee.."/pommels/thunder_hammer_pommel_03",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {0, -.5, .1},
            },
            thunder_hammer_pommel_04 = {
                replacement_path = _item_melee.."/pommels/thunder_hammer_pommel_04",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {0, -.5, .1},
            },
            thunder_hammer_pommel_05 = {
                replacement_path = _item_melee.."/pommels/thunder_hammer_pommel_05",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {0, -.5, .1},
            },
            thunder_hammer_pommel_ml01 = {
                replacement_path = _item_melee.."/pommels/thunder_hammer_pommel_ml01",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {0, -.5, .1},
            },
        }
    },
}
