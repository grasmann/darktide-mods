local mod = get_mod("extended_weapon_customization")

-- ##### ┬─┐┌─┐┌─┐ ┬ ┬┬┬─┐┌─┐ #########################################################################################
-- ##### ├┬┘├┤ │─┼┐│ ││├┬┘├┤  #########################################################################################
-- ##### ┴└─└─┘└─┘└└─┘┴┴└─└─┘ #########################################################################################

local muzzle_laspistol = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/muzzle_laspistol")
local muzzle_lasgun = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/muzzle_lasgun")
local trinket_hooks = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/trinket_hook")
local emblem_right = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/emblem_right")
local emblem_left = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/emblem_left")
local flashlights = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/flashlight")
local sights = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/sight")
local rails = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/rail")

-- ##### ┌─┐┌─┐┬─┐┌─┐┌─┐┬─┐┌┬┐┌─┐┌┐┌┌─┐┌─┐ ############################################################################
-- ##### ├─┘├┤ ├┬┘├┤ │ │├┬┘│││├─┤││││  ├┤  ############################################################################
-- ##### ┴  └─┘┴└─└  └─┘┴└─┴ ┴┴ ┴┘└┘└─┘└─┘ ############################################################################
-- #region Performance
    local table = table
    local vector3 = Vector3
    local vector3_box = Vector3Box
    local vector3_zero = vector3.zero
    local table_merge_recursive = table.merge_recursive
    local table_merge_recursive_n = table.merge_recursive_n
--#endregion

-- ##### ┌┬┐┌─┐┌┬┐┌─┐ #################################################################################################
-- #####  ││├─┤ │ ├─┤ #################################################################################################
-- ##### ─┴┘┴ ┴ ┴ ┴ ┴ #################################################################################################

local _item = "content/items/weapons/player"
local _item_ranged = _item.."/ranged"

local reflex_sights = "reflex_sight_01|reflex_sight_02|reflex_sight_03"
local scopes = "scope_01"

return {
    attachments = {
        emblem_left = emblem_left,
        emblem_right = emblem_right,
        trinket_hook = trinket_hooks,
        -- flashlight = flashlights,
        rail = rails,
        sight = sights,
        grip = {
            lasgun_pistol_grip_01 = {
                replacement_path = _item_ranged.."/grips/lasgun_pistol_grip_01",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {.075, -1, .05},
            },
            lasgun_pistol_grip_02 = {
                replacement_path = _item_ranged.."/grips/lasgun_pistol_grip_02",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {.075, -1, .05},
            },
            lasgun_pistol_grip_03 = {
                replacement_path = _item_ranged.."/grips/lasgun_pistol_grip_03",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {.075, -1, .05},
            },
            lasgun_pistol_grip_04 = {
                replacement_path = _item_ranged.."/grips/lasgun_pistol_grip_04",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {.075, -1, .05},
            },
            lasgun_pistol_grip_05 = {
                replacement_path = _item_ranged.."/grips/lasgun_pistol_grip_05",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {.075, -1, .05},
            },
            lasgun_pistol_grip_ml01 = {
                replacement_path = _item_ranged.."/grips/lasgun_pistol_grip_ml01",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {.075, -1, .05},
            },
        },
        stock = {
            lasgun_pistol_stock_01 = {
                replacement_path = _item_ranged.."/stocks/lasgun_pistol_stock_01",
                icon_render_unit_rotation_offset = {90, -10, -60},
                icon_render_camera_position_offset = {.035, .1, .15},
            },
            lasgun_pistol_stock_02 = {
                replacement_path = _item_ranged.."/stocks/lasgun_pistol_stock_02",
                icon_render_unit_rotation_offset = {90, -10, -60},
                icon_render_camera_position_offset = {.035, .1, .15},
            },
            lasgun_pistol_stock_03 = {
                replacement_path = _item_ranged.."/stocks/lasgun_pistol_stock_03",
                icon_render_unit_rotation_offset = {90, -10, -60},
                icon_render_camera_position_offset = {.035, .1, .15},
            },
            lasgun_pistol_stock_04 = {
                replacement_path = _item_ranged.."/stocks/lasgun_pistol_stock_04",
                icon_render_unit_rotation_offset = {90, -10, -60},
                icon_render_camera_position_offset = {.035, .1, .15},
            },
            lasgun_pistol_stock_ml01 = {
                replacement_path = _item_ranged.."/stocks/lasgun_pistol_stock_ml01",
                icon_render_unit_rotation_offset = {90, -10, -60},
                icon_render_camera_position_offset = {.035, .1, .15},
            },
        },
        muzzle = muzzle_laspistol,
        receiver = {
            lasgun_pistol_receiver_01 = {
                replacement_path = _item_ranged.."/recievers/lasgun_pistol_receiver_01",
                icon_render_unit_rotation_offset = {90, 0, 45},
                icon_render_camera_position_offset = {-.15, -1.75, .25},
            },
            lasgun_pistol_receiver_02 = {
                replacement_path = _item_ranged.."/recievers/lasgun_pistol_receiver_02",
                icon_render_unit_rotation_offset = {90, 0, 45},
                icon_render_camera_position_offset = {-.15, -1.75, .25},
            },
            lasgun_pistol_receiver_03 = {
                replacement_path = _item_ranged.."/recievers/lasgun_pistol_receiver_03",
                icon_render_unit_rotation_offset = {90, 0, 45},
                icon_render_camera_position_offset = {-.15, -1.75, .25},
            },
            lasgun_pistol_receiver_04 = {
                replacement_path = _item_ranged.."/recievers/lasgun_pistol_receiver_04",
                icon_render_unit_rotation_offset = {90, 0, 45},
                icon_render_camera_position_offset = {-.15, -1.75, .25},
            },
            lasgun_pistol_receiver_05 = {
                replacement_path = _item_ranged.."/recievers/lasgun_pistol_receiver_05",
                icon_render_unit_rotation_offset = {90, 0, 45},
                icon_render_camera_position_offset = {-.15, -1.75, .25},
            },
            lasgun_pistol_receiver_06 = {
                replacement_path = _item_ranged.."/recievers/lasgun_pistol_receiver_06",
                icon_render_unit_rotation_offset = {90, 0, 45},
                icon_render_camera_position_offset = {-.15, -1.75, .25},
            },
            lasgun_pistol_receiver_07 = {
                replacement_path = _item_ranged.."/recievers/lasgun_pistol_receiver_07",
                icon_render_unit_rotation_offset = {90, 0, 45},
                icon_render_camera_position_offset = {-.15, -1.75, .25},
            },
            lasgun_pistol_receiver_08 = {
                replacement_path = _item_ranged.."/recievers/lasgun_pistol_receiver_08",
                icon_render_unit_rotation_offset = {90, 0, 45},
                icon_render_camera_position_offset = {-.15, -1.75, .25},
            },
            lasgun_pistol_receiver_ml01 = {
                replacement_path = _item_ranged.."/recievers/lasgun_pistol_receiver_ml01",
                icon_render_unit_rotation_offset = {90, 0, 45},
                icon_render_camera_position_offset = {-.15, -1.75, .25},
            },
        },
        magazine = {
            lasgun_pistol_magazine_01 = {
                replacement_path = _item_ranged.."/magazines/lasgun_pistol_magazine_01",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {-.1, -1.5, -.05},
            },
            lasgun_pistol_magazine_02 = {
                replacement_path = _item_ranged.."/magazines/lasgun_pistol_magazine_02",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {-.1, -1.5, -.05},
                hide_from_selection = true,
            },
            lasgun_pistol_magazine_03 = {
                replacement_path = _item_ranged.."/magazines/lasgun_pistol_magazine_03",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {-.1, -1.5, -.05},
            },
            lasgun_pistol_magazine_04 = {
                replacement_path = _item_ranged.."/magazines/lasgun_pistol_magazine_04",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {-.1, -1.5, -.05},
                hide_from_selection = true,
            },
            lasgun_pistol_magazine_05 = {
                replacement_path = _item_ranged.."/magazines/lasgun_pistol_magazine_05",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {-.1, -1.5, -.05},
            },
            lasgun_pistol_magazine_ml01 = {
                replacement_path = _item_ranged.."/magazines/lasgun_pistol_magazine_ml01",
                icon_render_unit_rotation_offset = {90, 0, 30},
                icon_render_camera_position_offset = {-.1, -1.5, -.05},
            },
        },
        barrel = {
            lasgun_pistol_barrel_01 = {
                replacement_path = _item_ranged.."/barrels/lasgun_pistol_barrel_01",
                icon_render_unit_rotation_offset = {90, -20, 90 - 30},
                icon_render_camera_position_offset = {-.075, -1.25, .1},
            },
            lasgun_pistol_barrel_02 = {
                replacement_path = _item_ranged.."/barrels/lasgun_pistol_barrel_02",
                icon_render_unit_rotation_offset = {90, -20, 90 - 30},
                icon_render_camera_position_offset = {-.075, -1.25, .1},
            },
            lasgun_pistol_barrel_03 = {
                replacement_path = _item_ranged.."/barrels/lasgun_pistol_barrel_03",
                icon_render_unit_rotation_offset = {90, -20, 90 - 30},
                icon_render_camera_position_offset = {-.075, -1.25, .1},
            },
            lasgun_pistol_barrel_04 = {
                replacement_path = _item_ranged.."/barrels/lasgun_pistol_barrel_04",
                icon_render_unit_rotation_offset = {90, -20, 90 - 30},
                icon_render_camera_position_offset = {-.075, -1.25, .1},
            },
            lasgun_pistol_barrel_05 = {
                replacement_path = _item_ranged.."/barrels/lasgun_pistol_barrel_05",
                icon_render_unit_rotation_offset = {90, -20, 90 - 30},
                icon_render_camera_position_offset = {-.075, -1.25, .1},
            },
            lasgun_pistol_barrel_06 = {
                replacement_path = _item_ranged.."/barrels/lasgun_pistol_barrel_06",
                icon_render_unit_rotation_offset = {90, -20, 90 - 30},
                icon_render_camera_position_offset = {-.075, -1.25, .1},
            },
            lasgun_pistol_barrel_07 = {
                replacement_path = _item_ranged.."/barrels/lasgun_pistol_barrel_07",
                icon_render_unit_rotation_offset = {90, -20, 90 - 30},
                icon_render_camera_position_offset = {-.075, -1.25, .1},
            },
            lasgun_pistol_barrel_ml01 = {
                replacement_path = _item_ranged.."/barrels/lasgun_pistol_barrel_ml01",
                icon_render_unit_rotation_offset = {90, -20, 90 - 30},
                icon_render_camera_position_offset = {-.075, -1.25, .1},
            },
        },
    },
}
