local mod = get_mod("extended_weapon_customization")

-- ##### ┬─┐┌─┐┌─┐ ┬ ┬┬┬─┐┌─┐ #########################################################################################
-- ##### ├┬┘├┤ │─┼┐│ ││├┬┘├┤  #########################################################################################
-- ##### ┴└─└─┘└─┘└└─┘┴┴└─└─┘ #########################################################################################

local trinket_hooks = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/trinket_hook")
local emblem_left = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/emblem_left")
local emblem_right = mod:io_dofile("extended_weapon_customization/scripts/mods/ewc/attachments/emblem_right")

-- ##### ┌─┐┌─┐┬─┐┌─┐┌─┐┬─┐┌┬┐┌─┐┌┐┌┌─┐┌─┐ ############################################################################
-- ##### ├─┘├┤ ├┬┘├┤ │ │├┬┘│││├─┤││││  ├┤  ############################################################################
-- ##### ┴  └─┘┴└─└  └─┘┴└─┴ ┴┴ ┴┘└┘└─┘└─┘ ############################################################################
-- #region Performance
    local table = table
    local vector3 = Vector3
    local vector3_box = Vector3Box
    local vector3_zero = vector3.zero
    local table_merge_recursive = table.merge_recursive
--#endregion

-- ##### ┌┬┐┌─┐┌┬┐┌─┐ #################################################################################################
-- #####  ││├─┤ │ ├─┤ #################################################################################################
-- ##### ─┴┘┴ ┴ ┴ ┴ ┴ #################################################################################################

local _item = "content/items/weapons/player"
local _minion = "content/items/weapons/minions"
local _item_melee = _item.."/melee"
local _item_ranged = _item.."/ranged"
local _item_empty_trinket = _item.."/trinkets/unused_trinket"

return {
    attachments = {
        emblem_left = emblem_left,
        emblem_right = emblem_right,
        trinket_hook = trinket_hooks,
        shaft = {
            human_power_maul_shaft_07 = {
                replacement_path = _item_ranged.."/shafts/human_power_maul_shaft_07",
                icon_render_unit_rotation_offset = {90, -30, 0},
                icon_render_camera_position_offset = {.025, -1, .1},
            },
            human_power_maul_shaft_07_ml01 = {
                replacement_path = _item_ranged.."/shafts/human_power_maul_shaft_07_ml01",
                icon_render_unit_rotation_offset = {90, -30, 0},
                icon_render_camera_position_offset = {.025, -1, .1},
            },
            human_power_maul_shaft_deluxe01 = {
                replacement_path = _item_ranged.."/shafts/human_power_maul_shaft_deluxe01",
                icon_render_unit_rotation_offset = {90, -30, 0},
                icon_render_camera_position_offset = {.025, -1, .1},
            },
        },
        head = {
            human_power_maul_head_07 = {
                replacement_path = _item_melee.."/heads/human_power_maul_head_07",
                icon_render_unit_rotation_offset = {90, 30, 0},
                icon_render_camera_position_offset = {-.015, -.75, .3},
            },
            human_power_maul_head_07_ml01 = {
                replacement_path = _item_melee.."/heads/human_power_maul_head_07_ml01",
                icon_render_unit_rotation_offset = {90, 30, 0},
                icon_render_camera_position_offset = {-.015, -.75, .3},
            },
            human_power_maul_head_deluxe01 = {
                replacement_path = _item_melee.."/heads/human_power_maul_head_deluxe01",
                icon_render_unit_rotation_offset = {90, 30, 0},
                icon_render_camera_position_offset = {-.015, -.75, .3},
            },
        },
        connector = {
            human_power_maul_connector_08 = {
                replacement_path = _item_melee.."/connectors/human_power_maul_connector_08",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {-.025, -.75, .35},
            },
            human_power_maul_connector_08_ml01 = {
                replacement_path = _item_melee.."/connectors/human_power_maul_connector_08_ml01",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {-.025, -.75, .35},
            },
            human_power_maul_connector_deluxe01 = {
                replacement_path = _item_melee.."/connectors/human_power_maul_connector_deluxe01",
                icon_render_unit_rotation_offset = {90, 45, 0},
                icon_render_camera_position_offset = {-.025, -.75, .35},
            },
        },
    },
}
