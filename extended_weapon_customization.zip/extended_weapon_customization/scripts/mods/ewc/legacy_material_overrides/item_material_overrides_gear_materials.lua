﻿-- chunkname: @scripts/settings/equipment/item_material_overrides/item_material_overrides_gear_materials.lua

local material_overrides = {
	coated_wear_clean = {
		property_overrides = {
			chip_dirt = {
				0,
				0,
			},
		},
	},
	coated_wear_01 = {
		property_overrides = {
			chip_dirt = {
				0.24,
				0.2,
			},
		},
	},
	coated_wear_02 = {
		property_overrides = {
			chip_dirt = {
				0.4,
				0.4,
			},
		},
	},
	coated_wear_025 = {
		property_overrides = {
			chip_dirt = {
				0.5,
				0.5,
			},
		},
	},
	coated_wear_03 = {
		property_overrides = {
			chip_dirt = {
				0.6,
				0.6,
			},
		},
	},
	coated_wear_04 = {
		property_overrides = {
			chip_dirt = {
				0.75,
				0.8,
			},
		},
	},
	coated_wear_045 = {
		property_overrides = {
			chip_dirt = {
				0.85,
				0.8,
			},
		},
	},
	coated_wear_05 = {
		property_overrides = {
			chip_dirt = {
				1,
				0.9,
			},
		},
	},
	coated_wear_06 = {
		property_overrides = {
			chip_dirt = {
				1,
				0.9,
			},
		},
	},
	oxidized_wear_00 = {
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0,
				0,
			},
		},
	},
	oxidized_wear_01 = {
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_wear_02 = {
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_wear_03 = {
		property_overrides = {
			edge_chipping = {
				0.2,
			},
			oxid_level = {
				0.6,
				0.35,
			},
		},
	},
	oxidized_wear_04 = {
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.8,
				0.7,
			},
		},
	},
	oxidized_wear_05 = {
		property_overrides = {
			edge_chipping = {
				0.6,
			},
			oxid_level = {
				0.75,
				0.8,
			},
		},
	},
	oxidized_wear_06 = {
		property_overrides = {
			edge_chipping = {
				0.6,
			},
			oxid_level = {
				0.75,
				0.3,
			},
		},
	},
	outfit_dirt_01 = {
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	outfit_dirt_02 = {
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	outfit_dirt_03 = {
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	dirt_color_01 = {
		property_overrides = {
			dirt_color = {
				0.719,
				0.276,
				0,
			},
		},
	},
	dirt_color_02 = {
		property_overrides = {
			dirt_color = {
				0.133,
				0.024,
				0,
			},
		},
	},
	dirt_color_03 = {
		property_overrides = {
			dirt_color = {
				0.431,
				0.344,
				0.104,
			},
		},
	},
	dirt_color_04 = {
		property_overrides = {
			dirt_color = {
				0.225,
				0.117,
				0.03,
			},
		},
	},
	dirt_color_05 = {
		property_overrides = {
			dirt_color = {
				0.101,
				0.103,
				0.117,
			},
		},
	},
	dirt_color_06 = {
		property_overrides = {
			dirt_color = {
				0.128,
				0.1,
				0.084,
			},
		},
	},
	dirt_color_07 = {
		property_overrides = {
			dirt_color = {
				0.403,
				0.236,
				0.134,
			},
		},
	},
	oxidized_metal_steel_paint_forest_01_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_forest_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_forest_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_paint_forest_01_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_forest_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_forest_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_paint_forest_01_gold_01_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_forest_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.3,
				0.5,
			},
		},
	},
	oxidized_metal_steel_paint_forest_02_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_forest_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_forest_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_brass_02_steel_paint_forest_02_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_forest_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_01_steel_paint_forest_02_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_forest_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_paint_black_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_black_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_black_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_paint_black_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_black_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_black_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_paint_white_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_white_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_white_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_paint_01_red_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_red_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_red_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_paint_01_white_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_white_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_white_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_steel_paint_01_white_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_white_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_steel_paint_01_white_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_white_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_steel_paint_02_white_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_02_white_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_02_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_paint_01_white_gold_01_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_white_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_steel_paint_01_red_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_red_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_steel_paint_01_red_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_red_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_iron_steel_paint_01_red_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_red_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_iron_steel_paint_01_red_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_red_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_gold_steel_paint_01_red_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_red_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_paint_yellow_01_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_yellow_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.9,
			},
			oxid_level = {
				0.4,
				0.7,
			},
		},
	},
	oxidized_metal_steel_paint_yellow_02_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_yellow_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.9,
			},
			oxid_level = {
				0.4,
				0.7,
			},
		},
	},
	oxidized_metal_steel_paint_yellow_03_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_yellow_03_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.9,
			},
			oxid_level = {
				0.2,
				0.4,
			},
		},
	},
	oxidized_metal_iron_03_paint_yellow_02_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_yellow_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.9,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_iron_03_paint_white_01_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_white_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.9,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_01_paint_white_01_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_white_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_paint_01/steel_paint_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.9,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_nylon_gold_01_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/nylon_gold_01/nylon_gold_01_bc",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/nylon_gold_01/nylon_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/nylon_gold_01/nylon_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/nylon_gold_01/nylon_gold_01_bc",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/nylon_gold_01/nylon_gold_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/nylon_gold_01/nylon_gold_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0,
			},
			oxid_level = {
				0,
				0,
			},
		},
	},
	oxidized_metal_nylon_steel_01_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/nylon_steel_01/nylon_steel_01_bc",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/nylon_steel_01/nylon_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/nylon_steel_01/nylon_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/nylon_steel_01/nylon_steel_01_bc",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/nylon_steel_01/nylon_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/nylon_steel_01/nylon_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0,
			},
			oxid_level = {
				0,
				0,
			},
		},
	},
	oxidized_metal_steel_brass_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_brass_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_brass_steel_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_brass_steel_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_brass_02_steel_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_brass_02_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_iron_brass_02_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_brass_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_brass_02_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_brass_02_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.4,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_brass_02_wear_03 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.4,
			},
			oxid_level = {
				0.4,
				0.5,
			},
		},
	},
	oxidized_metal_brass_02_wear_04 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.65,
				0.52,
			},
		},
	},
	oxidized_metal_brass_02_gold_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_brass_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_03_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_03_brass_01_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_03_steel_01_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_03_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_gold_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_gold_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_gold_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_gold_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_silver_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/silver_01/metal_silver_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/silver_01/metal_silver_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/silver_01/metal_silver_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/silver_01/metal_silver_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/silver_01/metal_silver_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/silver_01/metal_silver_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_gold_brass_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_gold_steel_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_gold_steel_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_gold_iron_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_gold_iron_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_gold_iron_wear_03 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_iron_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_iron_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_steel_iron_wear_03 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_iron_02_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_iron_02_steel_01_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_02",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_02_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_iron_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_iron_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_iron_wear_03 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.4,
			},
			oxid_level = {
				0.7,
				0,
			},
		},
	},
	oxidized_metal_iron_03_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_iron_03_steel_01_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_steel_01_iron_03_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/steel_01/metal_steel_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_iron_03_brass_01_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_01/metal_brass_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_iron_03_brass_02_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_03_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_turquoise_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/brass_02/metal_brass_02_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_iron_gold_wear_01 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.3,
			},
			oxid_level = {
				0.1,
				0.3,
			},
		},
	},
	oxidized_metal_iron_gold_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	oxidized_metal_iron_gold_02_wear_02 = {
		texture_overrides = {
			oxid1_gradient = {
				resource = "content/textures/colors/oxidation_color_red_01",
			},
			oxid_mat1_bc = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_bca",
			},
			oxid_mat1_nm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_nm",
			},
			oxid_mat1_orm = {
				resource = "content/characters/tiling_materials/iron_01/metal_iron_01_orm",
			},
			oxid2_gradient = {
				resource = "content/textures/colors/oxidation_color_black_01",
			},
			oxid_mat2_bc = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_02_bca",
			},
			oxid_mat2_nm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_nm",
			},
			oxid_mat2_orm = {
				resource = "content/characters/tiling_materials/gold_01/metal_gold_01_orm",
			},
		},
		property_overrides = {
			edge_chipping = {
				0.5,
			},
			oxid_level = {
				0.2,
				0.5,
			},
		},
	},
	fabric_leather_02_plastic_hard_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_02_plastic_hard_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_02_plastic_hard_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_plastic_hard_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/plastic/plastic_hard_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_linen_worn_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_linen_worn_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_linen_worn_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_02_leather_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_02_leather_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_02_leather_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_cotton_01_leather_02_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_02_cotton_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_02_burlap_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_burlap_01_leather_02_wear_01 = {
		texture_overrides = {
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_cotton_01_leather_02_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_cotton_01_leather_02_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_cotton_01_leather_03_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_cotton_01_leather_03_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_cotton_01_leather_03_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_cotton_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_cotton_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_cotton_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_denim_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_denim_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_denim_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_denim_01_leather_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_denim_01_leather_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_denim_01_leather_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_denim_01_leather_03_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_denim_01_leather_03_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_denim_01_leather_03_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_denim_01_leather_coarse_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_denim_01_leather_coarse_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_denim_01_leather_coarse_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_cotton_01_denim_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_cotton_01_denim_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_linen_worn_denim_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_linen_worn_denim_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_linen_worn_denim_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_cotton_01_denim_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_denim/fabric_denim_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_cotton_01_burlap_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_cotton_01_burlap_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_cotton_01_burlap_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_burlap_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_burlap_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_burlap_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_burlap_01_wool_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_wool_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_wool_02_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_02_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_wool_02_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_wool_03_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_03/wool_03_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_03/wool_03_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_03/wool_03_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_03/wool_03_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_03/wool_03_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_03/wool_03_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_04_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_05_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_05/wool_05_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_05/wool_05_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_05/wool_05_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_05/wool_05_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_05/wool_05_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_05/wool_05_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_06_leather_03_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_06/wool_06_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_06/wool_06_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_06/wool_06_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_01_wool_02_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_01_wool_02_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_wool_01_wool_02_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_wool_02_wool_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_02_wool_02_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_02_wool_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_wool_02_wool_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_wool_02_leather_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_02_leather_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_wool_02_leather_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_01_wool_02_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_02/wool_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_course_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_02_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_02_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_02_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_03_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_03_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_03_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_03_pattern_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_03_pattern_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_03_pattern_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02_pattern_01/leather_02_pattern_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_04_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_04_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_04_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_04_wool_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_04_wool_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_04_wool_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_burlap_leather_04_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_03/leather_03_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_05_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_05_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_05_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_06_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_05/leather_05_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_05/leather_05_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_05/leather_05_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_07_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_06/leather_06_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_06/leather_06_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_06/leather_06_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_05_pattern_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_05_pattern_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_05_pattern_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_05_leather_05_pattern_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_05_leather_05_pattern_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_05_leather_05_pattern_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04_pattern_01/leather_04_pattern_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_wool_01_leather_tint_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_cotton_02_leather_tint_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linen_worn/linen_worn_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_01_leather_tint_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_wool_01_leather_tint_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_wool_04_leather_tint_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_tint_01_wool_04_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_03_leather_tint_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_tint_01_leather_03_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_tint_01_cotton_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/cotton_01/cotton_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_01_leather_02_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_01_leather_02_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_wool_01_leather_02_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_wool_01_leather_03_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_wool_01_leather_05_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_wool_01_leather_05_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_wool_01_leather_05_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_04/leather_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_01_wool_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_01_wool_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_01_wool_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_02_wool_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_02_wool_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_02_wool_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_01/leather_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_03_wool_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_03_burlap_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_03_wool_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_03_wool_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_coarse_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_coarse_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_coarse_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_coarse_wool_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_coarse_wool_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_coarse_wool_01_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_coarse/leather_coarse_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_01/wool_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_leather_damaged_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_leather_damaged_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_damaged_wear_03 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_damaged/leather_damaged_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.6,
			},
		},
	},
	fabric_vostroyan_brass_01_wear_01 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.1,
			},
		},
	},
	fabric_vostroyan_brass_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_vostroyan_silver_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_silver_01/fabric_silver_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_silver_01/fabric_silver_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_silver_01/fabric_silver_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_vostroyan_silver_01_wear_02_inv = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_silver_01/fabric_silver_01_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_silver_01/fabric_silver_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_silver_01/fabric_silver_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_vostroyan_gold_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_gold_01/fabric_gold_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_gold_01/fabric_gold_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_gold_01/fabric_gold_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_vostroyan_gold_01_wear_02_inv = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_gold_01/fabric_gold_01_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_gold_01/fabric_gold_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_gold_01/fabric_gold_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_vostroyan_brass_01_wear_02_inv = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_wool_04/wool_04_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_burlap_01_brass_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/linnen_burlap_irregular/linnen_burlap_irregular_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_tintable_brass_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_tintable_01/leather_tintable_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_01_brass_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_01_brass_01_wear_02_inv = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_bca",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_01_silver_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_02/leather_02_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_silver_01/fabric_silver_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_silver_01/fabric_silver_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_silver_01/fabric_silver_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	fabric_leather_02_brass_01_wear_02 = {
		texture_overrides = {
			mat1_bc = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_bc",
			},
			mat1_nm = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_nm",
			},
			mat1_orm = {
				resource = "content/characters/tiling_materials/leather_rough/leather_rough_orm",
			},
			mat2_bc = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_bca",
			},
			mat2_nm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_nm",
			},
			mat2_orm = {
				resource = "content/characters/tiling_materials/fabric_brass_01/fabric_brass_01_orm",
			},
		},
		property_overrides = {
			dirt = {
				0.3,
			},
		},
	},
	decal_blend_01 = {
		property_overrides = {
			bc_blend = {
				0.1,
			},
		},
	},
	decal_blend_02 = {
		property_overrides = {
			bc_blend = {
				0.2,
			},
		},
	},
	decal_blend_03 = {
		property_overrides = {
			bc_blend = {
				0.3,
			},
		},
	},
	decal_blend_04 = {
		property_overrides = {
			bc_blend = {
				0.4,
			},
		},
	},
	decal_blend_05 = {
		property_overrides = {
			bc_blend = {
				0.5,
			},
		},
	},
	decal_blend_06 = {
		property_overrides = {
			bc_blend = {
				0.6,
			},
		},
	},
	decal_blend_07 = {
		property_overrides = {
			bc_blend = {
				0.7,
			},
		},
	},
	decal_blend_08 = {
		property_overrides = {
			bc_blend = {
				0.8,
			},
		},
	},
	decal_blend_09 = {
		property_overrides = {
			bc_blend = {
				0.9,
			},
		},
	},
	decal_blend_10 = {
		property_overrides = {
			bc_blend = {
				1,
			},
		},
	},
	coated_decal_blend_01 = {
		property_overrides = {
			coated_decal_opacity = {
				0.1,
			},
		},
	},
	coated_decal_blend_02 = {
		property_overrides = {
			coated_decal_opacity = {
				0.2,
			},
		},
	},
	coated_decal_blend_03 = {
		property_overrides = {
			coated_decal_opacity = {
				0.3,
			},
		},
	},
	coated_decal_blend_04 = {
		property_overrides = {
			coated_decal_opacity = {
				0.4,
			},
		},
	},
	coated_decal_blend_05 = {
		property_overrides = {
			coated_decal_opacity = {
				0.5,
			},
		},
	},
	coated_decal_blend_06 = {
		property_overrides = {
			coated_decal_opacity = {
				0.6,
			},
		},
	},
	coated_decal_blend_07 = {
		property_overrides = {
			coated_decal_opacity = {
				0.7,
			},
		},
	},
	coated_decal_blend_08 = {
		property_overrides = {
			coated_decal_opacity = {
				0.8,
			},
		},
	},
	coated_decal_blend_09 = {
		property_overrides = {
			coated_decal_opacity = {
				0.9,
			},
		},
	},
	coated_decal_blend_10 = {
		property_overrides = {
			coated_decal_opacity = {
				1,
			},
		},
	},
	oxidized_decal_blend_01 = {
		property_overrides = {
			oxidized_decal_opacity = {
				0.1,
			},
		},
	},
	oxidized_decal_blend_02 = {
		property_overrides = {
			oxidized_decal_opacity = {
				0.2,
			},
		},
	},
	oxidized_decal_blend_03 = {
		property_overrides = {
			oxidized_decal_opacity = {
				0.3,
			},
		},
	},
	oxidized_decal_blend_04 = {
		property_overrides = {
			oxidized_decal_opacity = {
				0.4,
			},
		},
	},
	oxidized_decal_blend_05 = {
		property_overrides = {
			oxidized_decal_opacity = {
				0.5,
			},
		},
	},
	oxidized_decal_blend_06 = {
		property_overrides = {
			oxidized_decal_opacity = {
				0.6,
			},
		},
	},
	oxidized_decal_blend_07 = {
		property_overrides = {
			oxidized_decal_opacity = {
				0.7,
			},
		},
	},
	oxidized_decal_blend_08 = {
		property_overrides = {
			oxidized_decal_opacity = {
				0.8,
			},
		},
	},
	oxidized_decal_blend_09 = {
		property_overrides = {
			oxidized_decal_opacity = {
				0.9,
			},
		},
	},
	oxidized_decal_blend_10 = {
		property_overrides = {
			oxidized_decal_opacity = {
				1,
			},
		},
	},
}

return material_overrides
