local mod = get_mod("visible_equipment")

return {
	name = "visible_equipment",
	description = mod:localize("mod_description"),
	is_togglable = true,
}
