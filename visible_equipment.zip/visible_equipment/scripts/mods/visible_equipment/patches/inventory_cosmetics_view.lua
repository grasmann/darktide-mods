local mod = get_mod("visible_equipment")

-- ##### ┌─┐┌─┐┬─┐┌─┐┌─┐┬─┐┌┬┐┌─┐┌┐┌┌─┐┌─┐ ############################################################################
-- ##### ├─┘├┤ ├┬┘├┤ │ │├┬┘│││├─┤││││  ├┤  ############################################################################
-- ##### ┴  └─┘┴└─└  └─┘┴└─┴ ┴┴ ┴┘└┘└─┘└─┘ ############################################################################
-- #region Performance
    local CLASS = CLASS
--#endregion

-- ##### ┌─┐┬ ┬┌┐┌┌─┐┌┬┐┬┌─┐┌┐┌  ┬ ┬┌─┐┌─┐┬┌─┌─┐ ######################################################################
-- ##### ├┤ │ │││││   │ ││ ││││  ├─┤│ ││ │├┴┐└─┐ ######################################################################
-- ##### └  └─┘┘└┘└─┘ ┴ ┴└─┘┘└┘  ┴ ┴└─┘└─┘┴ ┴└─┘ ######################################################################

mod:hook(CLASS.InventoryCosmeticsView, "_preview_element", function(func, self, element, ...)
    -- Original function
    func(self, element, ...)
    -- Update equipment component
    if self._profile_spawner and self._profile_spawner._character_spawn_data then
        local equipment_component = self._profile_spawner._character_spawn_data.equipment_component
        equipment_component:position_objects()
    end
end)

mod:hook(CLASS.InventoryCosmeticsView, "_stop_previewing", function(func, self, ...)
    -- Original function
    func(self, ...)
    -- Update equipment component
    if self._profile_spawner and self._profile_spawner._character_spawn_data then
        local equipment_component = self._profile_spawner._character_spawn_data.equipment_component
        equipment_component:position_objects()
    end
end)
