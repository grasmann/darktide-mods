local mod = get_mod("visible_equipment")

-- ##### ┌─┐┌─┐┬─┐┌─┐┌─┐┬─┐┌┬┐┌─┐┌┐┌┌─┐┌─┐ ############################################################################
-- ##### ├─┘├┤ ├┬┘├┤ │ │├┬┘│││├─┤││││  ├┤  ############################################################################
-- ##### ┴  └─┘┴└─└  └─┘┴└─┴ ┴┴ ┴┘└┘└─┘└─┘ ############################################################################
-- #region Performance
    local CLASS = CLASS
    local managers = Managers
--#endregion

-- ##### ┌─┐┬ ┬┌┐┌┌─┐┌┬┐┬┌─┐┌┐┌  ┬ ┬┌─┐┌─┐┬┌─┌─┐ ######################################################################
-- ##### ├┤ │ │││││   │ ││ ││││  ├─┤│ ││ │├┴┐└─┐ ######################################################################
-- ##### └  └─┘┘└┘└─┘ ┴ ┴└─┘┘└┘  ┴ ┴└─┘└─┘┴ ┴└─┘ ######################################################################

mod:hook(CLASS.MainMenuView, "init", function(func, self, settings, context, ...)
    -- Original function
    func(self, settings, context, ...)
    -- Mod
    self._pass_input = true
end)

mod:hook(CLASS.MainMenuBackgroundView, "_spawn_profile", function(func, self, profile, ...)

    local primary_item = profile.loadout.slot_primary
    local secondary_item = profile.loadout.slot_secondary
    local primary_gear_id = primary_item and primary_item.__gear_id or primary_item.gear_id
    local secondary_gear_id = secondary_item and secondary_item.__gear_id or secondary_item.gear_id
    mod:gear_placement(primary_gear_id, nil, true)
    mod:gear_placement(secondary_gear_id, nil, true)

    -- Original function
    func(self, profile, ...)
end)
