local mod = get_mod("visible_equipment")

-- ##### ┌─┐┌─┐┬─┐┌─┐┌─┐┬─┐┌┬┐┌─┐┌┐┌┌─┐┌─┐ ############################################################################
-- ##### ├─┘├┤ ├┬┘├┤ │ │├┬┘│││├─┤││││  ├┤  ############################################################################
-- ##### ┴  └─┘┴└─└  └─┘┴└─┴ ┴┴ ┴┘└┘└─┘└─┘ ############################################################################
-- #region Performance
    local CLASS = CLASS
--#endregion

-- ##### ┌─┐┬ ┬┌┐┌┌─┐┌┬┐┬┌─┐┌┐┌  ┬ ┬┌─┐┌─┐┬┌─┌─┐ ######################################################################
-- ##### ├┤ │ │││││   │ ││ ││││  ├─┤│ ││ │├┴┐└─┐ ######################################################################
-- ##### └  └─┘┘└┘└─┘ ┴ ┴└─┘┘└┘  ┴ ┴└─┘└─┘┴ ┴└─┘ ######################################################################

mod:hook(CLASS.PortraitUI, "load_profile_portrait", function(func, self, profile, on_load_callback, optional_render_context, prioritized, on_unload_callback, ...)

    -- self.custom_position = nil
    if optional_render_context and optional_render_context.placement and optional_render_context.placement_name then
        mod.next_ui_profile_spawner_placement_name[profile.character_id] = optional_render_context.placement_name
    end

    -- Original function
    return func(self, profile, on_load_callback, optional_render_context, prioritized, on_unload_callback, ...)
end)
