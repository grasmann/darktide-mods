local mod = get_mod("visible_equipment")

-- ##### ┬─┐┌─┐┌─┐ ┬ ┬┬┬─┐┌─┐ #########################################################################################
-- ##### ├┬┘├┤ │─┼┐│ ││├┬┘├┤  #########################################################################################
-- ##### ┴└─└─┘└─┘└└─┘┴┴└─└─┘ #########################################################################################

local breed_folder = "visible_equipment/scripts/mods/visible_equipment/breeds/"
local ogryn = mod:io_dofile(breed_folder.."ogryn")
local human = mod:io_dofile(breed_folder.."human")
local weapons_folder = "visible_equipment/scripts/mods/visible_equipment/weapons/"
local ogryn_powermaul_slabshield_p1_m1 = mod:io_dofile(weapons_folder.."ogryn_powermaul_slabshield_p1_m1")
local ogryn_heavystubber_p1_m1 = mod:io_dofile(weapons_folder.."ogryn_heavystubber_p1_m1")
local ogryn_heavystubber_p2_m1 = mod:io_dofile(weapons_folder.."ogryn_heavystubber_p2_m1")
local ogryn_combatblade_p1_m1 = mod:io_dofile(weapons_folder.."ogryn_combatblade_p1_m1")
local shotpistol_shield_p1_m1 = mod:io_dofile(weapons_folder.."shotpistol_shield_p1_m1")
local ogryn_pickaxe_2h_p1_m1 = mod:io_dofile(weapons_folder.."ogryn_pickaxe_2h_p1_m1")
local powermaul_shield_p1_m1 = mod:io_dofile(weapons_folder.."powermaul_shield_p1_m1")
local thunderhammer_2h_p1_m1 = mod:io_dofile(weapons_folder.."thunderhammer_2h_p1_m1")
local ogryn_powermaul_p1_m1 = mod:io_dofile(weapons_folder.."ogryn_powermaul_p1_m1")
local ogryn_rippergun_p1_m1 = mod:io_dofile(weapons_folder.."ogryn_rippergun_p1_m1")
local ogryn_gauntlet_p1_m1 = mod:io_dofile(weapons_folder.."ogryn_gauntlet_p1_m1")
local chainsword_2h_p1_m1 = mod:io_dofile(weapons_folder.."chainsword_2h_p1_m1")
local forcesword_2h_p1_m1 = mod:io_dofile(weapons_folder.."forcesword_2h_p1_m1")
local ogryn_thumper_p1_m1 = mod:io_dofile(weapons_folder.."ogryn_thumper_p1_m1")
local powersword_2h_p1_m1 = mod:io_dofile(weapons_folder.."powersword_2h_p1_m1")
local powermaul_2h_p1_m1 = mod:io_dofile(weapons_folder.."powermaul_2h_p1_m1")
local stubrevolver_p1_m1 = mod:io_dofile(weapons_folder.."stubrevolver_p1_m1")
local combatknife_p1_m1 = mod:io_dofile(weapons_folder.."combatknife_p1_m1")
local combatsword_p1_m1 = mod:io_dofile(weapons_folder.."combatsword_p1_m1")
local combatsword_p2_m1 = mod:io_dofile(weapons_folder.."combatsword_p2_m1")
local combatsword_p3_m1 = mod:io_dofile(weapons_folder.."combatsword_p3_m1")
local boltpistol_p1_m1 = mod:io_dofile(weapons_folder.."boltpistol_p1_m1")
local chainsword_p1_m1 = mod:io_dofile(weapons_folder.."chainsword_p1_m1")
local forcestaff_p1_m1 = mod:io_dofile(weapons_folder.."forcestaff_p1_m1")
local forcesword_p1_m1 = mod:io_dofile(weapons_folder.."forcesword_p1_m1")
local ogryn_club_p1_m1 = mod:io_dofile(weapons_folder.."ogryn_club_p1_m1")
local ogryn_club_p2_m1 = mod:io_dofile(weapons_folder.."ogryn_club_p2_m1")
local powersword_p1_m1 = mod:io_dofile(weapons_folder.."powersword_p1_m1")
local combataxe_p1_m1 = mod:io_dofile(weapons_folder.."combataxe_p1_m1")
local combataxe_p2_m1 = mod:io_dofile(weapons_folder.."combataxe_p2_m1")
local combataxe_p3_m1 = mod:io_dofile(weapons_folder.."combataxe_p3_m1")
local laspistol_p1_m1 = mod:io_dofile(weapons_folder.."laspistol_p1_m1")
local plasmagun_p1_m1 = mod:io_dofile(weapons_folder.."plasmagun_p1_m1")
local powermaul_p1_m1 = mod:io_dofile(weapons_folder.."powermaul_p1_m1")
local powermaul_p2_m1 = mod:io_dofile(weapons_folder.."powermaul_p2_m1")
local chainaxe_p1_m1 = mod:io_dofile(weapons_folder.."chainaxe_p1_m1")
local autogun_p1_m1 = mod:io_dofile(weapons_folder.."autogun_p1_m1")
local shotgun_p1_m1 = mod:io_dofile(weapons_folder.."shotgun_p1_m1")
local shotgun_p2_m1 = mod:io_dofile(weapons_folder.."shotgun_p2_m1")
local shotgun_p4_m1 = mod:io_dofile(weapons_folder.."shotgun_p4_m1")
local bolter_p1_m1 = mod:io_dofile(weapons_folder.."bolter_p1_m1")
local flamer_p1_m1 = mod:io_dofile(weapons_folder.."flamer_p1_m1")
local lasgun_p1_m1 = mod:io_dofile(weapons_folder.."lasgun_p1_m1")
local lasgun_p2_m1 = mod:io_dofile(weapons_folder.."lasgun_p2_m1")
local lasgun_p3_m1 = mod:io_dofile(weapons_folder.."lasgun_p3_m1")

-- ##### ┌─┐┌─┐┬─┐┌─┐┌─┐┬─┐┌┬┐┌─┐┌┐┌┌─┐┌─┐ ############################################################################
-- ##### ├─┘├┤ ├┬┘├┤ │ │├┬┘│││├─┤││││  ├┤  ############################################################################
-- ##### ┴  └─┘┴└─└  └─┘┴└─┴ ┴┴ ┴┘└┘└─┘└─┘ ############################################################################
-- #region Performance
    local table = table
    local vector3 = Vector3
    local vector3_box = Vector3Box
    local vector3_zero = vector3.zero
    local table_clone_safe = table.clone_safe
--#endregion

-- ##### ┌┬┐┌─┐┌┬┐┌─┐ #################################################################################################
-- #####  ││├─┤ │ ├─┤ #################################################################################################
-- ##### ─┴┘┴ ┴ ┴ ┴ ┴ #################################################################################################

local BREED_HUMAN = "human"
local BREED_OGRYN = "ogryn"
local WEAPON_MELEE = "WEAPON_MELEE"
local WEAPON_RANGED = "WEAPON_RANGED"

local momentum = {
    [WEAPON_MELEE] = {
        right = {
            momentum = vector3_box(1, 0, -3),
        },
        left = {
            momentum = vector3_box(0, -3, -3),
        },
    },
    [WEAPON_RANGED] = {
        right = {
            momentum = vector3_box(1, 3, 0),
        },
        left = {
            momentum = vector3_box(0, -3, -3),
        },
    },
    ogryn_pickaxe_2h_p1_m1 = ogryn_pickaxe_2h_p1_m1.momentum,
    ogryn_rippergun_p1_m1 = ogryn_rippergun_p1_m1.momentum,
    ogryn_gauntlet_p1_m1 = ogryn_gauntlet_p1_m1.momentum,
    ogryn_thumper_p1_m1 = ogryn_thumper_p1_m1.momentum,
    forcestaff_p1_m1 = forcestaff_p1_m1.momentum,
    default = {
        right = {
            momentum = vector3_box(1, 0, -3),
        },
        left = {
            momentum = vector3_box(0, -3, -3),
        },
    },
}

--#endregion Copies
    --#region Ogryn melee
        momentum.ogryn_pickaxe_2h_p1_m2 = table_clone_safe(momentum.ogryn_pickaxe_2h_p1_m1)
        momentum.ogryn_pickaxe_2h_p1_m3 = table_clone_safe(momentum.ogryn_pickaxe_2h_p1_m1)
    --#endregion
    --#region Ogryn ranged
        momentum.ogryn_rippergun_p1_m2 = table_clone_safe(momentum.ogryn_rippergun_p1_m1)
		momentum.ogryn_rippergun_p1_m3 = table_clone_safe(momentum.ogryn_rippergun_p1_m1)
        momentum.ogryn_thumper_p1_m2 = table_clone_safe(momentum.ogryn_thumper_p1_m1)
    --#endregion
    --#region Human ranged
        momentum.forcestaff_p2_m1 = table_clone_safe(momentum.forcestaff_p1_m1)
        momentum.forcestaff_p3_m1 = table_clone_safe(momentum.forcestaff_p1_m1)
        momentum.forcestaff_p4_m1 = table_clone_safe(momentum.forcestaff_p1_m1)
    --#endregion
--#endregion

local placements = {
    default = "default",
    hip_front = "hip_front",
    hip_back = "hip_back",
    hip_left = "hip_left",
    hip_right = "hip_right",
    leg_left = "leg_left",
    leg_right = "leg_right",
    chest = "chest",
    POCKETABLE_SMALL = "POCKETABLE_SMALL",
    POCKETABLE = "POCKETABLE",
}

placements.backpack = placements.default

-- z = up / down
local placement_camera = {
    [BREED_HUMAN] = {
        default = {
            [WEAPON_RANGED] = {
                position = vector3_box(-1.1683889865875244, 2.639409065246582, 1.6318360567092896),
                rotation = 2.5,
            },
            [WEAPON_MELEE] = {
                position = vector3_box(-1.3683889865875244, 2.639409065246582, 1.6318360567092896),
                rotation = 4.5,
            },
        },
        POCKETABLE_SMALL = {
            position = vector3_box(-1.2683889865875244, 2.639409065246582, 1.6318360567092896),
            rotation = 3.5,
        },
        POCKETABLE = {
            position = vector3_box(-1.2683889865875244, 2.639409065246582, 1.6318360567092896),
            rotation = 3.5,
        },
        leg_left = {
            position = vector3_box(-1.1683889865875244, 2.639409065246582, 1.6318360567092896),
            rotation = 1,
        },
        leg_right = {
            position = vector3_box(-1.2683889865875244, 2.639409065246582, 1.6318360567092896),
            rotation = -.5,
        },
        hip_left = {
            position = vector3_box(-1.1683889865875244, 2.639409065246582, 1.6318360567092896),
            rotation = 1.5,
        },
        hip_right = {
            position = vector3_box(-1.2683889865875244, 2.639409065246582, 1.6318360567092896),
            rotation = -1,
        },
        hip_back = {
            position = vector3_box(-1.2683889865875244, 2.639409065246582, 1.6318360567092896),
            rotation = 3.5,
        },
        hip_front = {
            position = vector3_box(-1.2683889865875244, 2.639409065246582, 1.6318360567092896),
            rotation = .5,
        },
        chest = {
            position = vector3_box(-1.2683889865875244, 2.639409065246582, 1.6318360567092896),
            rotation = .5,
        },
    },
    [BREED_OGRYN] = {
        default = {
            [WEAPON_RANGED] = {
                position = vector3_box(-1.4683889865875244, 1.039409065246582, 2.0318360567092896),
                rotation = 2.5,
            },
            [WEAPON_MELEE] = {
                position = vector3_box(-2.0683889865875244, 1.039409065246582, 2.0318360567092896),
                rotation = 4.5,
            },
        },
        POCKETABLE_SMALL = {
            position = vector3_box(-1.5683889865875244, 1.039409065246582, 2.0318360567092896),
            rotation = 3.5,
        },
        POCKETABLE = {
            position = vector3_box(-1.5683889865875244, 1.039409065246582, 2.0318360567092896),
            rotation = 3.5,
        },
        leg_left = {
            position = vector3_box(-1.3683889865875244, 1.039409065246582, 2.0318360567092896),
            rotation = 1,
        },
        leg_right = {
            position = vector3_box(-1.8683889865875244, 1.039409065246582, 2.0318360567092896),
            rotation = -.5,
        },
        hip_left = {
            position = vector3_box(-1.4683889865875244, 1.039409065246582, 2.0318360567092896),
            rotation = 1.5,
        },
        hip_right = {
            position = vector3_box(-1.8683889865875244, 1.039409065246582, 2.0318360567092896),
            rotation = -1,
        },
        hip_back = {
            position = vector3_box(-1.7683889865875244, 1.039409065246582, 2.0318360567092896),
            rotation = 3.5,
        },
        hip_front = {
            position = vector3_box(-1.5683889865875244, 1.039409065246582, 2.0318360567092896),
            rotation = .5,
        },
        chest = {
            position = vector3_box(-1.5683889865875244, 1.039409065246582, 2.0318360567092896),
            rotation = .5,
        },
    },
}

placement_camera[BREED_HUMAN].backpack = placement_camera[BREED_HUMAN].default
placement_camera[BREED_OGRYN].backpack = placement_camera[BREED_OGRYN].default

return {
    sounds = mod:io_dofile("visible_equipment/scripts/mods/visible_equipment/utilities/sounds"),
    offsets = mod:io_dofile("visible_equipment/scripts/mods/visible_equipment/utilities/offsets"),
    animations = mod:io_dofile("visible_equipment/scripts/mods/visible_equipment/utilities/animations"),
    backpacks = mod:io_dofile("visible_equipment/scripts/mods/visible_equipment/utilities/backpacks"),
    momentum = momentum,
    placements = placements,
    placement_camera = placement_camera,
}
