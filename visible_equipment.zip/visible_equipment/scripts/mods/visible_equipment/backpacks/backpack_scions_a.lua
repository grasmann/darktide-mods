local mod = get_mod("visible_equipment")

return {
    width = 2,
}