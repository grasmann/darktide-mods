local mod = get_mod("visible_equipment")

local vector3_box = Vector3Box

return {
    right = {
        position = vector3_box(0, 0, 0),
        rotation = vector3_box(0, 0, 0),
    },
    left = {
        position = vector3_box(0, 0, 0),
        rotation = vector3_box(0, 0, 0),
    },
}