return {
	mod_description = {
		en = "visible_equipment description",
	},
}
